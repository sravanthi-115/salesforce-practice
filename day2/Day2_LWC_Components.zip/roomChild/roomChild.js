import { LightningElement, api } from 'lwc';

export default class RoomChild extends LightningElement {

    @api roomName;

    sendMessage() {

        const event = new CustomEvent('buttonclick', {
            detail: 'Child button clicked!'
        });

        this.dispatchEvent(event);
    }

}
import { LightningElement } from 'lwc';

export default class RoomParent extends LightningElement {

    roomName = 'Room 101';

    message = 'Waiting for child event...';

    handleButtonClick(event) {

        this.message = event.detail;

    }

}
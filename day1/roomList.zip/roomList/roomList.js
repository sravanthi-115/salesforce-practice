import { LightningElement, wire } from 'lwc';
import getRooms from '@salesforce/apex/RoomController.getRooms';

export default class RoomList extends LightningElement {

    rooms;
    error;

    @wire(getRooms)
    wiredRooms({ error, data }) {

        if (data) {
            this.rooms = data;
            this.error = undefined;
        } else if (error) {
            this.error = error;
            this.rooms = undefined;
        }
    }
}
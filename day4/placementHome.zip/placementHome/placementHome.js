import { LightningElement } from 'lwc';

import logo from '@salesforce/resourceUrl/VishnuLogo';

export default class PlacementHome extends LightningElement {

    logoUrl = logo;

    studentName = 'Rahul';

    rollNumber = '22B81A05XX';

    department = 'Information Technology';

    todayDate = new Date().toLocaleDateString();

    companies = 25;

    jobs = 63;

    applications = 5;

    status = 'Not Applied';

    message = '';

    showMessage() {

        this.message = 'Welcome to Salesforce Development.';

    }

    applyJob() {

        this.status = 'Applied';

    }

}